<!DOCTYPE html>
<html>
<head><title>Definiciones de los integrantes</title></head>
<body>
<h1>Equipo y sus chistes</h1>
<dl>
    <dt>Ana</dt>
    <dd>¿Por qué el café fue al psicólogo? Porque ya no podía más.</dd>
    <dt>Bruno</dt>
    <dd>¿Qué le dice una iguana a su hermana gemela? Somos iguanitas.</dd>
    <dt>Carmen</dt>
    <dd>¿Cuál es el animal más antiguo? La cebra, porque está en blanco y negro.</dd>
</dl>
<a href="index.html">⬅ Volver al menú</a>
</body>
</html>